<?php

namespace App\Models\Mosques;

use Illuminate\Database\Eloquent\Model;

class Mosque extends Model
{
    // protected $fillable = ['mosques_name'];
    
    public function Mosque_information_provider()
    {
    	return $this->belongsTo('App\Models\Mosques\Mosque_information_provider');
    }

    public function Mosque_institution()
    {
    	return $this->belongsTo('App\Models\Mosques\Mosque_institution');
    }

    public function Mosque_treasure()
    {
    	return $this->belongsTo('App\Models\Mosques\Mosque_treasure');
    }
}
